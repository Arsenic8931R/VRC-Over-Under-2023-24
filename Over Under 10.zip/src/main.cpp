/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\squid                                            */
/*    Created:      Mon Aug 28 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// MotorFR              motor         16              
// MotorBR              motor         17              
// MotorMR              motor         2               
// MotorFL              motor         6               
// MotorBL              motor         19              
// MotorML              motor         8               
// Puncher              motor         18              
// PuncherPos           rotation      11              
// Intake               motor         20              
// WingPiston           digital_out   H               
// InertialSensor       inertial      12              
// Hang                 digital_out   C               
// Blocker              digital_out   D               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

double Auto;

int AutoCode = 0;
double AutoCodeTime[100];
double AutoCodeError[100];
double StartingPos;
double InitialTime;


double cmove;
double TrackingCircum = (10.21018 * 5)/3; //8.63938
double totalmoved;

double chead;
double MotorValues;
double shead;
double constant = 3;
double smove;
double DirectionFix;
double TotalTurn = 0;
double LeftError;
double RightError;

double EncoderAverage = 0;

double TimeList[300];
double ManipulatedList[300];

//Stops all drivetrain motors
void MotorStop()
{
  MotorBL.spin(fwd,0,pct);
  MotorML.spin(fwd,0,pct);
  MotorFL.spin(fwd,0,pct);
  MotorBR.spin(fwd,0,pct);
  MotorMR.spin(fwd,0,pct);
  MotorFR.spin(fwd,0,pct);

  MotorBL.setBrake(hold);
  MotorML.setBrake(hold);
  MotorFL.setBrake(hold);
  MotorBR.setBrake(hold);
  MotorMR.setBrake(hold);
  MotorFR.setBrake(hold);
}


double sPos = 0;
double robotVelocity;
double tuningValue = 7;
//Moves the robot forwards a for a spesifyed number of inches

void MotorCoast()
{
  MotorBL.setBrake(coast);
  MotorML.setBrake(coast);
  MotorFL.setBrake(coast);
  MotorBR.setBrake(coast);
  MotorMR.setBrake(coast);
  MotorFR.setBrake(coast);
}

double a = -0.000240918;
double c = 2.77397;
//double hShift = 3;
void MoveForwards(double inches, bool forwards,int speed)
  {
    constant = 3;
    MotorFR.setPosition(0,rev);
    EncoderAverage = MotorFR.position(rev);
    
    smove = EncoderAverage * TrackingCircum;
    printf("smove: %f\n",smove);
    printf("DirectionFix this%f\n",DirectionFix);
    DirectionFix = 1;
    MotorValues = 50;
    LeftError = 0;
    RightError = 0;
    printf("DirectionFix now%f\n",DirectionFix);
    if (forwards == true)
      {
        DirectionFix = 1;
      }
        else
          {
            DirectionFix = -1;
          } 
    printf("DirectionFix then%f\n",DirectionFix);  
    printf("detaMove: %f\n",(smove - (EncoderAverage * TrackingCircum)));
    if (inches > (smove - (EncoderAverage * TrackingCircum)))
    {
      printf("clause 1 TRUE\n");
    }
    else
    {
      printf("clause 1 FALSE\n");
    }
    if ((MotorValues > (constant+0.3)))
    {
      printf("clause 2 TRUE\n");
    }
    else
    {
      printf("clause 2 FALSE\n");
    }
    if ((inches > (smove - (EncoderAverage * TrackingCircum))  ) and (MotorValues > (constant+0.3)) )
    {
      printf("AND is TRUE\n");
    }
    else
    {
      printf("AND is FALSE\n");
    }

    printf("MotorValues: %f\n",MotorValues);
    while((inches > (smove - (EncoderAverage * TrackingCircum))  ) and ((MotorValues > (constant+0.3))) )
      {
        printf("It gets here\n");
        EncoderAverage = MotorFR.position(rev);

        MotorValues = ( speed * ( 1 - ( ((EncoderAverage*TrackingCircum * DirectionFix) - smove ) / (inches) ) ) ) ;
        MotorValues = (a*pow(MotorValues,3.0) + c * MotorValues) + (constant * DirectionFix);

        MotorValues = MotorValues * DirectionFix;
        MotorBL.spin(fwd,MotorValues,pct);
        MotorML.spin(fwd,MotorValues,pct);
        MotorFL.spin(fwd,MotorValues,pct);
        MotorBR.spin(fwd,MotorValues,pct);
        MotorMR.spin(fwd,MotorValues,pct);
        MotorFR.spin(fwd,MotorValues,pct);
        MotorValues = fabs(MotorValues);
    printf("MotorValues: %f\n",MotorValues);
    //printf("Constant: %f\n",constant);
    if (inches > (smove - (EncoderAverage * TrackingCircum)))
    {
      printf("clause 1 TRUE\n");
    }
    else
    {
      printf("clause 1 FALSE\n");
    }
    if ((MotorValues > (constant+0.3) * DirectionFix * -1))
    {
      printf("clause 2 TRUE\n");
    }
    else
    {
      printf("clause 2 FALSE\n");
    }
    if ((inches > (smove - (EncoderAverage * TrackingCircum))  ) and (MotorValues > (constant+0.3)) )
    {
      printf("AND is TRUE\n");
    }
    else
    {
      printf("AND is FALSE\n");
    }
      }
      MotorStop(); 
      /*inches += hShift;
      while( EncoderAverage + 0.1 < inches)
      {
        printf("\nPosi %f",MotorFR.position(rev));
        printf("\nTime %f",Brain.Timer.value());
        EncoderAverage = ((MotorFR.position(rev) * MotorBR.position(rev) * MotorMR.position(rev) * MotorBL.position(rev) * MotorFL.position(rev) * MotorML.position(rev))/6) * TrackingCircum ;
        EncoderAverage += hShift;
        robotVelocity = (EncoderAverage + 0.01) - sPos; //calculates num 1-100 for velocity
        //printf("Calculated X value: %f\n", robotVelocity);//outputs x value
        robotVelocity = (-0.01) * (100/inches) * 3.14159265 * robotVelocity; //calculates the item under the sin function
        //printf("item in the sin: %f\n", robotVelocity); //outputs value under the sin
        robotVelocity = sin(robotVelocity);
        //printf("sin of that item: %f\n", robotVelocity); //outputs value after sin
        robotVelocity = 1/robotVelocity; //converts the sin -> csc
        //printf("1/sin of the item: %f\n" ,robotVelocity); //outputs the csc of the item
        robotVelocity = robotVelocity * tuningValue; //verticaly stretchs the function to make it rounder edges
        //printf("vertical stretch value: %f\n", robotVelocity); //outputs vertical stretch value
        robotVelocity = robotVelocity + speed; //vertical translation up by the speed
        printf("\nFinal Velocity: %f\n\n", robotVelocity); //outputs final value
      */
    /*if (robotVelocity < constant)
        {
            robotVelocity = constant;
        }*/

    //robotVelocity*=-1;
   /*
    robotVelocity = fabs(robotVelocity);//find absolute value of robot velocity
    if (!forwards)
    {
      robotVelocity *= -1;
    }

    MotorBL.spin(fwd,robotVelocity,pct);
    MotorML.spin(fwd,robotVelocity,pct);
    MotorFL.spin(fwd,robotVelocity,pct);
    MotorBR.spin(fwd,robotVelocity,pct);
    MotorMR.spin(fwd,robotVelocity,pct);
    MotorFR.spin(fwd,robotVelocity,pct);
    //printf("\nActual Final Number: %f\n\n",robotVelocity);
  }
  MotorStop();

  while (1)
  {
    EncoderAverage = ((MotorFR.position(rev) * MotorBR.position(rev) * MotorMR.position(rev) * MotorBL.position(rev) * MotorFL.position(rev) * MotorML.position(rev))/6) * TrackingCircum ;
    robotVelocity = (EncoderAverage + 0.01) - sPos; //calculates num 1-100 for velocity
    printf("Calculated X value: %f\n", robotVelocity);//outputs x value
  } */
  }

bool left2;
//Turns a specified number of degrees
void Turn(int TurnValue,int speed)
  {
    left2 = true;
    if (TurnValue < 0)
    {
      left2 = false;
    }
    TotalTurn = TotalTurn + TurnValue;
    MotorValues = 1;
  for(int i = 0; i < 5;i++)
    {
      while( !(TotalTurn == round(InertialSensor.rotation(deg) ) ) and !(round(MotorValues) == 0) )
        {
          MotorValues = ( speed * ( 1 - ( ( InertialSensor.rotation(deg) - (TotalTurn-TurnValue)) / TurnValue ) ) );
      MotorValues = round(MotorValues);
      if(left2)
        {
      MotorBL.spin(fwd,MotorValues,pct);
      MotorML.spin(fwd,MotorValues,pct);
      MotorFL.spin(fwd,MotorValues,pct);
      MotorBR.spin(fwd,MotorValues*-1,pct);
      MotorMR.spin(fwd,MotorValues*-1,pct);
      MotorFR.spin(fwd,MotorValues*-1,pct);
        }
          else
            {
      MotorBL.spin(reverse,MotorValues,pct);
      MotorML.spin(reverse,MotorValues,pct);
      MotorFL.spin(reverse,MotorValues,pct);
      MotorBR.spin(reverse,MotorValues*-1,pct);
      MotorMR.spin(reverse,MotorValues*-1,pct);
      MotorFR.spin(reverse,MotorValues*-1,pct);
            }
        }
        MotorStop();
        wait(0.1,sec);
    }
  }


//Driver control Drivetrain
void Driving() //Driver control, puts onto a cubic function
  {
      double joystickL = ((0.0000530602 * pow(Controller1.Axis3.position(),3.0)) + 0.469292*Controller1.Axis3.position()) + ( (0.000025392 * pow(Controller1.Axis1.position(),3.0)) + (0.745584 * Controller1.Axis1.position()) );
      double joystickR = ((0.0000530602 * pow(Controller1.Axis3.position(),3.0)) + 0.469292*Controller1.Axis3.position()) - ( (0.000025392 * pow(Controller1.Axis1.position(),3.0) + (0.745584 * Controller1.Axis1.position())) );
      //printf("Left %f\n",joystickL);
      //printf("Right %f\n",joystickR);
      MotorFR.spin(fwd,joystickR, pct); //moves all the motors forwards
      MotorFL.spin(fwd,joystickL, pct);
      MotorMR.spin(fwd,joystickR, pct);
      MotorML.spin(fwd,joystickL, pct);
      MotorBR.spin(fwd,joystickR, pct);
      MotorBL.spin(fwd,joystickL, pct);
  }

void Punch()
{
  Puncher.spin(reverse,95,pct);
  wait(0.5,sec);
  waitUntil(PuncherPos.position(deg) >= 62);
  Puncher.spin(fwd,0,pct);
}
//Driver control Puncher code
void PuncherCode()
{
  if (Controller1.ButtonR2.pressing())
  {
    Puncher.setBrake(coast);
    Puncher.spin(reverse,95,pct);
  }
  else if (PuncherPos.position(deg) >= 60)
  {
    Puncher.spin(fwd,0,pct);
    Puncher.setBrake(coast);
  }
  else
  {
    Puncher.spin(reverse,95,pct);
  }
}

//Driver control Spins intake
void IntakeCode()
{
  if (Controller1.ButtonL1.pressing())
  {
    Intake.spin(fwd,100,pct);
  }
  else if (Controller1.ButtonL2.pressing())
  {
    Intake.spin(fwd,-100,pct);
  }
  else
  {
    Intake.spin(fwd,0,pct);
  }
}

//Driver control Wing deploy code
void WingCode()
{
  if (Controller1.ButtonUp.pressing()) {
    WingPiston.set(true);
  }
  else if (Controller1.ButtonDown.pressing()) {
    WingPiston.set(false);
  }
}

void HangCode() 
{
  if (Controller1.ButtonY.pressing()) {
    Hang.set(true);
  }
}

void BlockerCode()
{
 if (Controller1.ButtonA.pressing()) {
    Blocker.set(true);
  }
  else if (Controller1.ButtonX.pressing()) {
    Blocker.set(false);
  } 
}
//preAuto stuff
void AutoSelection(int Mod)
  {
      Brain.Screen.drawImageFromFile("AutoSelector2.png",0,0); 
      wait(0.5,sec);
      waitUntil(Brain.Screen.pressing());

      if(Brain.Screen.xPosition() > 240)
        {
          if(Brain.Screen.yPosition() > 136)
            {
              Auto = 4 + Mod;
            }
            else
              {
                Auto = 2 + Mod;
              }
        }
          else
            {
              if(Brain.Screen.yPosition() > 136)
                {
                  Auto = 3 + Mod;
                }
                  else
                    {
                      Auto = 1 + Mod;
                    }
            }

  }

bool Skills;

void pre_auton(void) {
  // Initializing Robot Configuration
  vexcodeInit();
  Controller1.Screen.clearScreen();
  Controller1.Screen.print("PreAuto");
  PuncherPos.resetPosition();
  MotorFR.setPosition(0,rev);
  MotorMR.setPosition(0,rev);
  MotorBR.setPosition(0,rev);
  MotorFL.setPosition(0,rev);
  MotorML.setPosition(0,rev);
  MotorBL.setPosition(0,rev);


  InertialSensor.calibrate();
  Brain.Screen.printAt(50, 50, false, "Calibrating..."); //Calibrates the Inertia sensor so heading is accurate
  waitUntil(!InertialSensor.isCalibrating());
  Brain.Screen.printAt(50, 50, false, "Not Calibrating");

  Brain.Screen.drawImageFromFile("MatchTypeSelector2.png",0,0); //starts the GUI that sets up the right Autonomous for matches or skills
  waitUntil(Brain.Screen.pressing());
  Brain.Screen.clearScreen();
  if(Brain.Screen.xPosition() > 240 ) //detects what side of the screen got pushed
    {
      Skills = false;
      Brain.Screen.drawImageFromFile("TeamSelector.png", 0, 0); //select either blue or red side for matches
      wait(0.5,sec);
      waitUntil(Brain.Screen.pressing());
      Brain.Screen.clearScreen();
        if(Brain.Screen.xPosition() > 240 )
          {
            AutoSelection(0);
            Brain.Screen.clearScreen();
            Brain.Screen.drawImageFromFile("VEXbrainScreen.png",0,0); //logo for Red side
            //Brain.Screen.drawImageFromFile("RedFox2.png",380,172); 
            Controller1.Screen.setCursor(0, 0);
            Controller1.Screen.print("Auto %f",Auto); //prints the auto on controller to make sure the right one was selected
          }
            else
              {
                AutoSelection(4);
                Brain.Screen.clearScreen();
                Brain.Screen.drawImageFromFile("VEXbrainScreen.png",380,172); 
                //Brain.Screen.drawImageFromFile("FerociousFoxLogoBlue.png",0,0); //logo for Blue side
                Controller1.Screen.setCursor(0, 0);
                Controller1.Screen.print("Auto %f",Auto);
                if (Auto == 8)
                  {
                    while(true)
                      {
                        Brain.Screen.clearScreen();
                        Brain.Screen.drawImageFromFile("Youareanidiot1.png",58,0); //Brain demonstation video
                        wait(0.05,sec);
                        Brain.Screen.setFillColor(white);
                        Brain.Screen.drawRectangle(0, 0, 480, 272);
                        Brain.Screen.drawImageFromFile("idiot2.png", 57, 0);
                        wait(0.05,sec);
                      }

                  }
              }

    }
      else
        {
          Skills = true;
          Brain.Screen.clearScreen();
      Brain.Screen.drawImageFromFile("SkillsSelector.png",0,0); //auto selector for skills
      wait(0.5,sec);
      waitUntil(Brain.Screen.pressing());

      if(Brain.Screen.xPosition() > 240)
        {
          if(Brain.Screen.yPosition() > 136)
            {
              Auto = 4;
            }
            else
              {
                Auto = 2;
                  Controller1.Screen.setCursor(0, 0);
                  Controller1.Screen.print("Auto %f",Auto);
              }
        }
          else
            {
              if(Brain.Screen.yPosition() > 136)
                {
                  Auto = 3;
                }
                  else
                    {
                      Auto = 1;
                    }
            }
            Controller1.Screen.setCursor(0, 0);
            Controller1.Screen.print("Auto %f",Auto);
            Brain.Screen.clearScreen();
            Brain.Screen.drawImageFromFile("BlueShark2.png",480,172);
            Brain.Screen.drawImageFromFile("FerociousFoxLogoBlue.png",0,0); 
        }
  
while(true)
  {
    wait(1,sec); //does nothing until it exits preauto
  }
}



//comp template
void usercontrol(void)
{
  Controller1.Screen.clearScreen();
  Controller1.Screen.print("User Control");
  Hang.set(false);

  


  while(true)
  {
    Driving();
    WingCode();
    IntakeCode();
    PuncherCode();
    HangCode();
    BlockerCode();
  }

}

void autonomous(void)
{
  
  TotalTurn = 0;
  //Skills = true;
  //Auto = 1;
  
if(Skills)
  {
  if (Auto == 1) //skills prog autonomous
    {
      InertialSensor.calibrate();
  Brain.Screen.printAt(50, 50, false, "Calibrating..."); //Calibrates the Inertia sensor so heading is accurate
  waitUntil(!InertialSensor.isCalibrating());
  Brain.Screen.printAt(50, 50, false, "Not Calibrating");


  MoveForwards(15,true,10);
  Turn(67, 35);
  wait(0.5,sec);
  for(int i = 0; i <49; i++) {
    Punch();
    
  }
  Turn(-70,35);
  MoveForwards(16,false,10);
  Turn(50,25);
  MoveForwards(80.5,false,99);

 
  Turn(90, 45);
  MoveForwards(22, false, 50);
  Turn(90, 45);
  MoveForwards(24, false, 60);
  Turn(-90,45);
  MoveForwards(22, false, 40);
  Turn(-90, 45);
  
  WingPiston.set(true);
  MoveForwards(28, false, 99);
  WingPiston.set(false);
  MoveForwards(28, true, 70);
  Turn(-90, 45);
  MoveForwards(10, true, 39);
  Turn(90, 45);
  WingPiston.set(true);
  MoveForwards(28, false, 99);
  WingPiston.set(false);
  MoveForwards(28, true, 70);
  Turn(-90, 45);
  Intake.spin(fwd, 100, pct);
  MoveForwards(36, true, 70);
  Turn(54, 25);
  WingPiston.set(true);
  MoveForwards(50, false, 90);
    }
  }
else //non skills ---
{
  if (Auto == 1)
  {
    //Match load side auto (Winpoint)
    MoveForwards(7.5, true, 10);
    WingPiston.set(true);
    MoveForwards(3.5, false, 7);
    Turn(-45, 20);
    WingPiston.set(false);
    Turn(42,15);
    MoveForwards(7, true, 30);
    Turn(45, 20);
    MoveForwards(7.5, true, 40);
    Intake.spin(fwd,100,pct);
    wait(0.5, sec);
    Intake.spin(fwd,0,pct);
    MoveForwards(3, false, 13);
    Turn(180, 90);
    MoveForwards(12.5, false, 40);
    MoveForwards(3, true, 10);
    Turn(-40, 20);
    MoveForwards(32, true, 70);
    Turn(-43, 20);
    MoveForwards(24.5, true, 70);
    Intake.spin(fwd,100,pct);
    wait(0.5, sec);
    Intake.spin(fwd,0,pct);
  }

  if(Auto == 2)
  {
    //goal side code (4 tribals scored)
    MoveForwards(8,false,40);
    WingPiston.set(true);
    MoveForwards(9.5, true, 15);
    Turn(-60,45);
    WingPiston.set(false);
    Turn(85, 35);
    MoveForwards(30,false,60);
    MoveForwards(2, true, 2);
    Turn(-20,10);
    MoveForwards(35, true, 50);
    Turn(-47, 20);
    MoveForwards(26, true, 30);
    Intake.spin(fwd,100,pct);
    wait(0.5, sec);
    Intake.spin(fwd,0,pct);
  }
}
}

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
